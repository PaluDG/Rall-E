package org.firstinspires.ftc.teamcode;

import android.app.Activity;
import android.graphics.Color;
import android.view.View;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.ColorSensor;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.DigitalChannel;
import com.qualcomm.robotcore.hardware.DistanceSensor;
import com.qualcomm.robotcore.hardware.NormalizedColorSensor;
import com.qualcomm.robotcore.hardware.NormalizedRGBA;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.hardware.SwitchableLight;
import com.qualcomm.robotcore.util.ElapsedTime;
import com.qualcomm.robotcore.util.Range;
import com.qualcomm.hardware.rev.Rev2mDistanceSensor;
import com.qualcomm.robotcore.hardware.DigitalChannel;

import org.firstinspires.ftc.robotcontroller.external.samples.SensorDigitalTouch;
import org.firstinspires.ftc.robotcore.external.navigation.DistanceUnit;
@TeleOp(name = "Rall-e")

public class Rall_e extends OpMode{
    private DcMotor backLeft = null;
    private DcMotor backRight = null;
    private DcMotor frontLeft = null;
    private DcMotor frontRight = null;
    private DcMotor brat = null;

    private Servo cleste = null;
    private DcMotor motorcleste = null;


    public void init(){
        telemetry.addData("Status", "Initialised");
        frontRight  = hardwareMap.get(DcMotor.class, "fr");
        frontLeft = hardwareMap.get(DcMotor.class, "fl");
        backRight = hardwareMap.get(DcMotor.class, "br");
        backLeft = hardwareMap.get(DcMotor.class,"bl");
        brat = hardwareMap.get(DcMotor.class, "brat");
        cleste = hardwareMap.get(Servo.class, "cleste");
        motorcleste = hardwareMap.get(DcMotor.class, "motorcleste");

        frontRight.setDirection(DcMotor.Direction.REVERSE);
        frontLeft.setDirection(DcMotor.Direction.FORWARD);
        backRight.setDirection(DcMotor.Direction.REVERSE);
        backLeft.setDirection(DcMotor.Direction.FORWARD);
        brat.setDirection(DcMotor.Direction.FORWARD);
        cleste.setPosition(0.5);
        motorcleste.setDirection(DcMotor.Direction.FORWARD);

        telemetry.addData("status", "initialised");
    }
    @Override
    public void init_loop() {
    }
    @Override

    public void loop(){
        double frontLeftPower;
        double frontleftvericu;
        double frontRightPower;
        double frontrightvericu;
        double backLeftPower;
        double backleftvericu;
        double backRightPower;
        double backrightvericu;

        double frontleftslow;
        double frontrightslow;
        double backrightslow;
        double backleftslow;

        double frontleftburnout;
        double frontrightburnout;
        double backrightburnout;
        double backleftburnout;


        double armupPower = gamepad1.right_trigger;
        double armdownPower = -gamepad1.left_trigger;
        double bratPower;
        double drive = gamepad1.left_stick_y;
        double slide = -gamepad1.left_stick_x;
        double turn = gamepad1.right_stick_x;
        double varsat = 0;
        double clestepower = 0;
        frontRightPower = Range.clip(drive + turn - slide, -0.4, 0.4);
        frontLeftPower = Range.clip(drive - turn + slide, -0.4, 0.4);
        backRightPower = Range.clip(drive + turn + slide, -0.4, 0.4);
        backLeftPower = Range.clip(drive - turn - slide, -0.4, 0.4);
        bratPower = Range.clip(armupPower + armdownPower, -0.75, 0.75);

        frontleftvericu = Range.clip(drive - turn + slide, -1.0, 1.0);
        frontrightvericu = Range.clip(drive + turn - slide, -1.0, 1.0);
        backrightvericu = Range.clip(drive + turn + slide, -1.0, 1.0);
        backleftvericu = Range.clip(drive - turn - slide, -1.0, 1.0);

        frontleftslow = Range.clip(drive - turn + slide, -0.2, 0.2);
        frontrightslow = Range.clip(drive + turn - slide, -0.2, 0.2);
        backrightslow = Range.clip(drive + turn + slide, -0.2, 0.2);
        backleftslow = Range.clip(drive - turn - slide, -0.2, 0.2);

        frontleftburnout = Range.clip(drive - turn + slide, -5.0, 5.0);
        frontrightburnout = Range.clip(drive + turn - slide, -5.0, 5.0);
        backrightburnout = Range.clip(drive + turn + slide, -1.0, 1.0);
        backleftburnout = Range.clip(drive - turn - slide, -1.0, 1.0);





        frontRight.setPower(frontRightPower);
        frontLeft.setPower(frontLeftPower);
        backRight.setPower(backRightPower);
        backLeft.setPower(backLeftPower);
        brat.setPower(bratPower);
        motorcleste.setPower(varsat);




        if(frontLeftPower==0)
            frontLeft.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        if(frontRightPower==0)
            frontRight.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        if(backLeftPower==0)
            backLeft.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        if(backRightPower==0)
            backRight.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        if(bratPower==0)
            brat.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        if(varsat==0)
            motorcleste.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);

        if(bratPower == 0)
        {
            bratPower = -0.2;
            brat.setPower(bratPower);
        }

        if (gamepad1.dpad_right)
        {
            varsat = varsat + 0.5;
            motorcleste.setPower(varsat);
        }

        motorcleste.setPower(varsat);

        if (gamepad1.dpad_left)
        {
            varsat = varsat - 0.5;
            motorcleste.setPower(varsat);
        }

        motorcleste.setPower(varsat);

        if (gamepad1.dpad_up)
            cleste.setPosition(0.8);
        if (gamepad1.dpad_down && cleste.getPosition()>0.7)
            cleste.setPosition(0);


        if(gamepad1.right_bumper)
        {
            frontRight.setPower(frontrightvericu);
            frontLeft.setPower(frontleftvericu);
            backRight.setPower(backrightvericu);
            backLeft.setPower(backleftvericu);
        }

        if(gamepad1.left_bumper)
        {
            frontRight.setPower(frontrightslow);
            frontLeft.setPower(frontleftslow);
            backRight.setPower(backrightslow);
            backLeft.setPower(backleftslow);
        }

        if(gamepad1.a)
        {
            frontRight.setPower(-frontrightburnout);
            frontLeft.setPower(-frontleftburnout);
            backRight.setPower(backrightburnout);
            backLeft.setPower(backleftburnout);

            if(frontLeftPower==0)
                frontLeft.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
            if(frontRightPower==0)
                frontRight.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
            if(backLeftPower==0)
                backLeft.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
            if(backRightPower==0)
                backRight.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        }

        telemetry.addData("Servo: ", cleste.getPosition());
        telemetry.update();

    }
}
